<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="text" name="s" placeholder="<?php _e( 'Search', 'linor' ); ?>" />
	<input type="submit" value="<?php _e( 'Search', 'linor' ); ?>" />
</form>