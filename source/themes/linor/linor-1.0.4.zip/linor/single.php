<?php get_header(); ?>
<?php if (have_posts()): while (have_posts()): the_post(); ?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="meta">
			<a class="date" href="<?php the_permalink(); ?>"><?php the_date(); ?></a> | 
			<?php comments_popup_link(__('Comment','linor'),__('1 comment','linor'),__('% comments','linor')); ?>
		</div>
		<h1 class="title"><?php the_title(); ?></h1>
		<div class="entry">
			<?php the_content(); ?>
			<div class="clearfix"></div>
			<?php wp_link_pages(); ?>
			<footer>
				<div class="sharing"><?php get_template_part('sharing'); ?></div>
				<div class="categories"><strong><?php _e('Categories', 'linor') ?></strong><?php the_category(', ', 'multiple'); ?></div>
				<div class="tags"><strong><?php _e('Tags', 'linor') ?></strong><?php the_tags('', ', ', ''); ?></div>
			</footer>
		</div>
	</article>
	<div class="clear"></div>
	<?php comments_template('', true); ?>
	<?php endwhile; ?>
<?php else: get_template_part('search','failed'); endif; ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>