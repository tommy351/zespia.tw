<?php get_header(); ?>
<?php get_template_part('loop','index'); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>