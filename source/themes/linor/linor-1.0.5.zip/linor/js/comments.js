(function() {
  var $, $comments, $trackback, insert, textarea;

  $ = jQuery;

  $comments = $('#comments');

  $trackback = $('#trackback');

  textarea = $('#comment')[0];

  insert = function(before, after) {
    var cursorPos, endPos, sel, startPos;
    if (after == null) after = '';
    if (document.selection) {
      textarea.focus();
      sel = document.selection.createRange();
      sel.text = before + sel.text + after;
      return textarea.focus();
    } else {
      if ((textarea.selectionStart != null) && (textarea.selectionEnd != null)) {
        startPos = textarea.selectionStart;
        endPos = textarea.selectionEnd;
        cursorPos = endPos;
        textarea.value = textarea.value.substring(0, startPos) + before + textarea.value.substring(startPos, endPos) + after + textarea.value.substring(endPos, textarea.value.length);
        if (startPos === endPos) {
          cursorPos += before.length;
        } else {
          cursorPos += before.length + after.length;
        }
        textarea.focus();
        return textarea.selectionStart = textarea.selectionEnd = cursorPos;
      } else {
        textarea.value += before + after;
        return textarea.focus();
      }
    }
  };

  $comments.delegate('.comment-quote-link', 'click', function() {
    var author, comment, content, string;
    author = $(this).parent().parent().find('.author');
    comment = $(this).parent().parent().parent().parent().attr('id');
    content = $(this).parent().parent().parent().children('.entry').html();
    string = "<blockquote cite='#" + comment + "'>\n<strong><a href='#" + (author.attr('id')) + "'>" + (author.html().replace(/\t|\n|\r\n/g, '')) + "</a> : </strong>\n" + (content.replace(/\t/g, '')) + "</blockquote>\n";
    return insert(string);
  }).delegate('.comment-reply-link', 'click', function() {
    var author, string;
    author = $(this).parent().parent().find('.author');
    string = "<a href='#" + (author.attr('id')) + "'>@" + (author.html().replace(/\t|\n|\r\n/g, '')) + "</a> ";
    return insert(string);
  });

  $('#cancel-comment-reply-link').click(function() {
    return $(textarea).val('');
  });

  $('.comment-form-comment').delegate('.bold', 'click', function() {
    return insert('<strong>', '</strong>');
  }).delegate('.italic', 'click', function() {
    return insert('<em>', '</em>');
  }).delegate('.delete', 'click', function() {
    return insert('<del>', '</del>');
  }).delegate('.link', 'click', function() {
    var url;
    url = prompt('Url: ', 'http://');
    if (url) {
      return insert("<a href='" + url + "' rel='external' target='_blank'>", '</a>');
    }
  }).delegate('.quote', 'click', function() {
    return insert('<blockquote>', '</blockquote>');
  }).delegate('.image', 'click', function() {
    var title, url;
    url = prompt('Url: ', 'http://');
    if (url) {
      title = prompt('Title: ');
      if (title) {
        return insert("<img src='" + url + "' alt='" + title + "'>\n");
      } else {
        return insert("<img src='" + url + "'>\n");
      }
    }
  }).delegate('.code', 'click', function() {
    var syntax;
    syntax = prompt('Syntax: ');
    if (syntax) {
      return insert("<pre lang='" + syntax + "'>", '</pre>');
    } else {
      return insert('<code>', '</code>');
    }
  });

  $(textarea).focus(function() {
    return $(this).parent().addClass('focus');
  }).blur(function() {
    return $(this).parent().removeClass('focus');
  }).keydown(function(e) {
    var code;
    code = e.keyCode || e.which;
    if (e.ctrlKey && code === 13) return $('#commentform #submit').click();
  });

  $('.comment a').click(function(e) {
    var target, url;
    url = $(this).attr('href');
    if (url.substring(0, 1) === '#') {
      target = $('#' + url.replace(/^#/, ''));
      return $('html, body').scrollTop(target.offset().top - target.height());
    }
  });

}).call(this);
