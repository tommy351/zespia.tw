	<div class="clearfix"></div>
	<footer>
		&copy; <?php echo date('Y').' '.get_bloginfo('name'); ?><br>
		Theme designed by <a href="http://zespia.tw">SkyArrow</a>. Powered by <a href="http://wordpress.org">WordPress</a>
	</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>