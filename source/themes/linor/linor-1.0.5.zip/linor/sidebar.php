<aside class="alignright">
	<?php if (is_single()) {
		if (is_active_sidebar('sidebar-post')){
			dynamic_sidebar('sidebar-post');
		} else {
			if (is_active_sidebar('sidebar-home')){
				dynamic_sidebar('sidebar-home');
			} else {
				get_template_part('sidebar','default');
			}
		}
	} else {
		if (is_active_sidebar('sidebar-home')){
			dynamic_sidebar('sidebar-home');
		} else {
			get_template_part('sidebar','default');
		}
	} ?>
</aside>