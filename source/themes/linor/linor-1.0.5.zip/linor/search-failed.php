<article class="page">
	<h1 class="title">404 Not Found</h1>
	<div class="entry">
		<p>Want to find something?</p>
		<p><?php get_search_form(); ?></p>
	</div>
</article>