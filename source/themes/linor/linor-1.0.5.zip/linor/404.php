<?php get_header(); ?>
<?php get_template_part('search','failed'); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>